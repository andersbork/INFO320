# INFO320
Code for application for semester project INFO320

1. run file start_ontop.bat
2. run command: python app.py
